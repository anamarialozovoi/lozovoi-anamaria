package Command;

interface Command {
    void execute();
}
