package Command;

class Receiver {
    public void addToCart() {
    }

    public void placeOrder() {
    }
}
