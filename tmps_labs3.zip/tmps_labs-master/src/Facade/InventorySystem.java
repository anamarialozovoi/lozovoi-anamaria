package Facade;

public class InventorySystem {
    public void checkAvailability(Product product) {
        // Check product availability in inventory
    }
}
