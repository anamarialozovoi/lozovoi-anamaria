package Facade;

public class PaymentSystem {
    public void processPayment(Order order) {
        // Process the payment for the order
    }
}
