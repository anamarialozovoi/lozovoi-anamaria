package Facade;

public class ShippingSystem {
    public void shipOrder(Order order) {
        // Ship the order to the customer
    }
}
