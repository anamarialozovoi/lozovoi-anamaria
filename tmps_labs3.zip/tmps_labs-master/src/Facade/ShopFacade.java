package Facade;

public interface ShopFacade {
    void placeOrder(Order order);
}
