package Flyweight;

public interface Product {
    void display();
}

