package Iterator;

interface ProductCollection {
    Iterator<Product> createIterator();
}
