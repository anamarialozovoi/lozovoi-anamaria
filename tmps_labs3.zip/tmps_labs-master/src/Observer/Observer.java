package Observer;

interface Observer {
    void update(Product product);
}
